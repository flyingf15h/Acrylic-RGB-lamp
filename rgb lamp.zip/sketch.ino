#include <FastLED.h>
#define NUM_LEDS 18 // 30cm of led strip with 60 LEDs/ meter 
#define LED_PIN 6 
#define PIN_LEFT 7
#define PIN_MID 8

CRGB leds[NUM_LEDS];

// first section for Arlecchino second for Furina
int sectionStart[] = {0, 9};
int sectionEnd[] = {8, 17};

uint8_t sectionHue[] = {0, 128};  
uint8_t rainbowHue = 0;
void setup() {
  FastLED.addLeds<WS2812B, LED_PIN, GRB>(leds, NUM_LEDS);
  FastLED.setBrightness(128);
  pinMode(PIN_LEFT, INPUT_PULLUP);
  pinMode(PIN_MID, INPUT_PULLUP);
}

void loop() {
  bool leftOn = (digitalRead(PIN_LEFT) == LOW);
  bool midOn = (digitalRead(PIN_MID) == LOW);

  uint8_t knob = map(analogRead(A0), 0, 1023, 0, 255); 

  // right for rainbow 
  if(!leftOn && !midOn) {
    uint8_t spd = map(knob, 0, 255, 5, 50); 
    for(int i = sectionStart[0]; i <= sectionEnd[0]; i++) {
      leds[i] = CHSV(rainbowHue, 255, 255); 
    }
    for(int i = sectionStart[1]; i<= sectionEnd[1]; i++) {
      leds[i] = CHSV(255-rainbowHue, 255, 255);
    }
    rainbowHue++;
    FastLED.show();
    delay(spd);
  } else if (leftOn) { // left to change Arlecchino
    sectionHue[0] = knob;
    for (int i = sectionStart[0]; i <= sectionEnd[0]; i++) {
      leds[i] = CHSV(sectionHue[0], 255, 255); 
    } 
    for(int i = sectionEnd[0]; i <= sectionEnd[0]; i++) {
      leds[i] = CHSV(sectionHue[1], 255, 255);
    }
    FastLED.show();
    delay(50);
  } else if (midOn) { // middle to change Furina
    sectionHue[1] = knob;
    for (int i = sectionStart[0]; i <= sectionEnd[0]; i++) {
      leds[i] = CHSV(sectionHue[0], 255, 255); 
    } 
    for(int i = sectionEnd[0]; i <= sectionEnd[0]; i++) {
      leds[i] = CHSV(sectionHue[1], 255, 255);
    }
    FastLED.show();
    delay(50);
  }

}
